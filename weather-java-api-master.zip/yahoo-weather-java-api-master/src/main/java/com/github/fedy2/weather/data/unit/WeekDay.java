package com.github.fedy2.weather.data.unit;

/**
 * @author "Federico De Faveri defaveri@gmail.com"
 */
public enum WeekDay {
	MON,
	TUE,
	WED,
	THU,
	FRI,
	SAT,
	SUN;
}
